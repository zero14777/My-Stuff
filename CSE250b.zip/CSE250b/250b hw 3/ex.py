import struct
import random
import math
import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neighbors import KDTree
from scipy.stats import multivariate_normal

def read_idx(filename):
    with open(filename, 'rb') as file:
        zero, data_type, dims = struct.unpack('>HBB', file.read(4))
        shape = tuple(struct.unpack('>I', file.read(4))[0] for d in range(dims))
        return np.fromstring(file.read(), dtype=np.uint8).reshape(shape)

def normalize_image(img_vec):
    for i in range(0, len(img_vec)):
        img_vec[i] = img_vec[i]/255
    return img_vec
    
def best_guess(cov_matricies, means, X, classProbs):
    probI = []
    guesses = []
    for i in range(0, 10):
        probI.append(multivariate_normal.logpdf(X, means[i], cov_matricies[i]))
        
    for exx in range(0, 10000):
        prob = 0
        guess = -1
        for i in range(0, 10):
            if((probI[i][exx]) > prob or guess == -1):
                prob = probI[i][exx]
                guess = i
        guesses.append(guess)
    return guesses
    
def reelTest():
    ceee = 1500
    testCeee = []
    testData = []
    maxRes = 0
    maxCee = 0
    while (ceee <= 4000):
        result = main(ceee)
        if(result > maxRes):
            maxRes = result
            maxCee = ceee
        print(ceee, " test %: ", result)
        testCeee.append(ceee)
        testData.append(result)
        ceee = ceee + 10
        
    print("MaxCee: ", maxCee, " MaxRes: ", maxRes)
    plt.plot(testCeee, testData)
    plt.ylabel('validation accuracy')
    plt.xlabel('c value')
    plt.title('validation performance by c value')
    plt.show()
    
def main(cee):
    train_data = read_idx("train-images.idx3-ubyte")
    train_labels = read_idx("train-labels.idx1-ubyte")
    test_data = read_idx("t10k-images.idx3-ubyte")
    test_labels = read_idx("t10k-labels.idx1-ubyte")
    
    #train
    
    train = []
    
    for i in range(0, 60000):
        train.append((train_data[i], train_labels[i]))
    
    #random.shuffle(train)
        
    correct = 0
    for crossV in range(0, 6):
            #Loading data

        trainD = []
        trainL = []
        trainMats = []
        validD = []
        validL = []
        classProb = [0]*10
        classMean = []
        stdDev = []
        covarianceMatricies = []

        for i in range(0, 10):
            trainMats.append([])
            classMean.append(np.asarray(([0]*784), dtype=np.dtype(float)).reshape(-1))
            stdDev.append(np.asarray(([0]*784), dtype=np.dtype(float)).reshape(-1))

        for i in range(0, (crossV*10000)):
            #trainD.append(np.asarray(train[i][0], dtype=np.dtype(float)).reshape(-1))
            #trainL.append(train[i][1])
            trainMats[train[i][1]].append(np.asarray(train[i][0], dtype=np.dtype(float)).reshape(-1))
            classProb[train[i][1]] = classProb[train[i][1]] + 1
            classMean[train[i][1]] = np.add(classMean[train[i][1]], np.asarray(train[i][0], dtype=np.dtype(float)).reshape(-1))

        for i in range((crossV*10000), ((crossV*10000)+10000)):
            validD.append(np.asarray(train[i][0], dtype=np.dtype(float)).reshape(-1))
            validL.append(train[i][1])

        for i in range(((crossV*10000)+10000), 60000):
            #trainD.append(np.asarray(train[i][0], dtype=np.dtype(float)).reshape(-1))
            #trainL.append(train[i][1])
            trainMats[train[i][1]].append(np.asarray(train[i][0], dtype=np.dtype(float)).reshape(-1))
            classProb[train[i][1]] = classProb[train[i][1]] + 1
            classMean[train[i][1]] = np.add(classMean[train[i][1]], np.asarray(train[i][0], dtype=np.dtype(float)).reshape(-1))

        for i in range(0, 10):
            classMean[i] = classMean[i] / classProb[i]
            covarianceMatricies.append(np.add(np.cov(np.asmatrix(trainMats[i]).T), (cee * np.identity(784))))

        for i in range(0, 10):
            classProb[i] = classProb[i] / 50000

        """

        for i in range(0, 50000):
            temp = np.subtract(trainD[i], classMean[train[i][1]])
            stdDev[train[i][1]] = np.add(stdDev[train[i][1]], temp)

        for i in range(0, 10):
            stdDev[i] = stdDev[i] / classProb[i]

        covarianceMatricies = []
        for i in range(0, 10):
            covarianceMatricies.append(np.outer(stdDev[i], stdDev[i]))
        """
        """
        covarianceMatricies = []
        for i in range(0, 10):
            covarianceMatricies.append(np.outer(np.asarray(([0]*784), dtype=np.dtype(float)).reshape(-1), np.asarray(([0]*784), dtype=np.dtype(float)).reshape(-1)))
        print("making cov matricies")
        for i in range(0, 50000):
            print(i)
            for x in range(0, 784):
                for y in range(0, 784):
                    covarianceMatricies[train[i][1]][x][y] = (trainD[i][x] - classMean[train[i][1]][x]) *  (trainD[i][y] - classMean[train[i][1]][y])
        print("done with cov matricies")
        for i in range(0, 10):
            covarianceMatricies[i] = covarianceMatricies[i] / classProb[i]
        """

        test = []

        for i in range(0, 10000):
            test.append((test_data[i], test_labels[i]))

        testD = []
        testL = []
        for i in range(0, 10000):
            testD.append(np.asarray(test[i][0], dtype=np.dtype(float)).reshape(-1))
            testL.append(test[i][1])

        print("Going around the neighborhood:")
        guesses = best_guess(covarianceMatricies, classMean, validD, classProb)
        for i in range(0, 10000):
            if(guesses[i] == validL[i]):
                correct = correct + 1

    return correct/60000

def testResults(cee):
    train_data = read_idx("train-images.idx3-ubyte")
    train_labels = read_idx("train-labels.idx1-ubyte")
    test_data = read_idx("t10k-images.idx3-ubyte")
    test_labels = read_idx("t10k-labels.idx1-ubyte")
    
    #train
    
    train = []
    
    for i in range(0, 60000):
        train.append((train_data[i], train_labels[i]))
        
    correct = 0
    if(1 == 1):
        #Loading data

        trainD = []
        trainL = []
        trainMats = []
        validD = []
        validL = []
        classProb = [0]*10
        classMean = []
        stdDev = []
        covarianceMatricies = []

        for i in range(0, 10):
            trainMats.append([])
            classMean.append(np.asarray(([0]*784), dtype=np.dtype(float)).reshape(-1))
            stdDev.append(np.asarray(([0]*784), dtype=np.dtype(float)).reshape(-1))

        for i in range(0, 60000):
            trainMats[train[i][1]].append(np.asarray(train[i][0], dtype=np.dtype(float)).reshape(-1))
            classProb[train[i][1]] = classProb[train[i][1]] + 1
            classMean[train[i][1]] = np.add(classMean[train[i][1]], np.asarray(train[i][0], dtype=np.dtype(float)).reshape(-1))
            
        for i in range(0, 10):
            classMean[i] = classMean[i] / classProb[i]
            covarianceMatricies.append(np.add(np.cov(np.asmatrix(trainMats[i]).T), (cee * np.identity(784))))

        for i in range(0, 10):
            classProb[i] = classProb[i] / 60000
        test = []

        for i in range(0, 10000):
            test.append((test_data[i], test_labels[i]))

        testD = []
        testL = []
        for i in range(0, 10000):
            testD.append(np.asarray(test[i][0], dtype=np.dtype(float)).reshape(-1))
            testL.append(test[i][1])

        print("Going around the neighborhood:")
        guesses = best_guess(covarianceMatricies, classMean, testD, classProb)
        for i in range(0, 10000):
            if(guesses[i] == testL[i]):
                correct = correct + 1
    return correct/10000

testResults(3170)