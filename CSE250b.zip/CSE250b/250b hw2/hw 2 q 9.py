#!/usr/bin/env python

import struct

import numpy as np

import matplotlib.pyplot as plt
import math
from random import gauss

my_meanX = 0
my_varianceX = 9

random_numbersX = [gauss(my_meanX, math.sqrt(my_varianceX)) for i in range(100)]

my_meanY = 0
my_varianceY = 1

random_numbersY = [gauss(my_meanY, math.sqrt(my_varianceY)) for i in range(100)]

# Print images
plt.plot(random_numbersX, random_numbersY, 'o')

plt.show()