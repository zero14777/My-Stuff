#!/usr/bin/env python

import struct

import numpy as np

import matplotlib.pyplot as plt
import math
from random import gauss

mean = [0, 0]
cov = [[4, -1], [-1, 4]]  # diagonal covariance

x, y = np.random.multivariate_normal(mean, cov, 100).T
plt.plot(x, y, 'o')
plt.axis('equal')
plt.show()