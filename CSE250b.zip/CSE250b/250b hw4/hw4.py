#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import csv
import random
import numpy as np
import matplotlib.pyplot as plt
from sklearn import linear_model, datasets
from sklearn.datasets import load_wine

def TEST(trainSamples):
    #Load Data
    file = open("mystery.dat", "r") 
    lines = file.readlines()
    
    data = []
    
    for i in range(0, len(lines)):
        data.append(lines[i].split(','))
        
    formatingData = np.asarray(data, dtype=float)
    formatingData = formatingData.T
    print(formatingData.shape, formatingData[73][0])
    
    Y = []
    for i in range(0, 101):
        Y.append(formatingData[100][i])
    Y = np.asarray(Y)
    X = formatingData
    for i in range(0, 101):
        X[100][i] = 1
    X = X.T
    #trainSamples = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99]#[1, 2, 4, 6, 10, 12, 16, 18, 22, 28]
    
    #trainSamples = [1, 4, 6, 10, 12, 16, 18, 22, 28]
    Xtemp = X[:, trainSamples]

    # Create linear regression object
    regr = linear_model.LinearRegression()

    # Train the model using the training sets
    regr.fit(Xtemp, Y)

    return regr.score(Xtemp, Y)
    
    """
    asdf = []
    for i in range(0, 101):
        trainSamples = [i]
        Xtemp = X[:, trainSamples]

        # Create linear regression object
        regr = linear_model.LinearRegression()

        # Train the model using the training sets
        regr.fit(Xtemp, Y)
        
        asdf.append(regr.score(Xtemp, Y))
    final = []
    for i in range(0, 11):
        maxPos = 0
        for j in range(1, 100):
            if(asdf[j] > asdf[maxPos]):
                maxPos = j
        final.append(maxPos)
        asdf[maxPos] = 0
    final.sort()
    print(final)
    """
    
    
    """
    looking = 9
    while(1 == 1):
        Xtemp = X[:, trainSamples]
    
        # Create linear regression object
        regr = linear_model.LinearRegression()

        # Train the model using the training sets
        regr.fit(Xtemp, Y)

        # Make predictions using the testing set
        print(regr.score(Xtemp, Y))
        if((looking == 9 and trainSamples[looking] < 99)):
            trainSamples[looking] = trainSamples[looking]+1
        if((looking != 9 and (trainSamples[looking]+1) < trainSamples[looking+1])):
            trainSamples[looking] = trainSamples[looking]+1
        elif(looking == 0):
            break
    """

def decent(W, X, Y, lammy):
    devMat = np.matmul(X, W)
    toBSqared = Y - devMat
    noLongerSquared = 2 * toBSqared
    unMeaned = np.matmul(X.T, noLongerSquared)
    meaned = unMeaned / len(X)
    lassuBonus = W
    output = (meaned + (lammy * (W / np.linalg.norm(W))))
    #print(noLongerSquared.shape, X.shape, lassuBonus)
    #input("asdf")
    return output
    #lassoEle = (lammy * W) /np.linalg.norm(W)
    #X
    #probs = sigmoid(W, X, negY)
    #Yprobs = (Y.flatten() * probs)
    #decentVect = np.dot(X.T, Yprobs)
    #meanDecentVect = (decentVect/(len(Y)))
    #return meanDecentVect

def LossA(W, X, Y, lammy):
    devMat = np.matmul(X, W)
    toBSqared = Y - devMat
    sumVal = np.power(toBSqared, 2).sum()
    regularizer = lammy * np.linalg.norm(W) * len(X)
    return (sumVal + regularizer)

def main(earlyBreakCount, learningRate, lammy):
    
    #Load Data
    file = open("mystery.dat", "r") 
    lines = file.readlines()
    
    data = []
    
    for i in range(0, len(lines)):
        data.append(lines[i].split(','))
        
    formatingData = np.asarray(data, dtype=float)
    formatingData = formatingData.T
    print(formatingData.shape, formatingData[73][0])
    
    Y = []
    for i in range(0, 101):
        Y.append(formatingData[100][i])
    Y = np.asarray(Y)
    X = formatingData
    for i in range(0, 101):
        X[100][i] = 1
    X = X.T
    
    print(Y)
    #print(X.shape, Y.shape, X[0], Y[0])
    #W = np.zeros((101, 1), dtype=float)
    W = np.random.rand(101, 1)*.001

    
    validSamples = random.sample(list(range(0, 101)),  10)
    trainSamples = []
    
    for i in range (0, 101):
        if (i not in validSamples):
            trainSamples.append(i)
    validX = X[validSamples, :]
    validY = Y[validSamples]
    trainX = X[trainSamples, :]
    trainY = Y[trainSamples]
    
    validY = np.reshape(validY, (len(validY), 1))
    trainY = np.reshape(trainY, (len(trainY), 1))
    
    #TestLoss
    lastTrainLoss = LossA(W, trainX, trainY, lammy)
    lastValidLoss = LossA(W, validX, validY, lammy)
    #print(lastTrainLoss)
    #print(lastValidLoss)
    
    validLosses = [lastValidLoss]
    for i in range (0, earlyBreakCount):
        validLosses.append(lastValidLoss)
    iter = 0
    while (1 == 1):
        meanDecentGradient = decent(W, trainX, trainY, lammy)
        W = W + (learningRate * meanDecentGradient)
        #print(W.shape, meanDecentGradient)
        #input("hol up")
        
        currValidLoss = (LossA(W, validX, validY, lammy))
        validLosses.append(currValidLoss)
        iter = iter + 1
        #print("Iter:",iter," Valid Loss:",currValidLoss)
        breakCond = 0
        for i in range (0, earlyBreakCount):
            if(validLosses[iter+1+i] > validLosses[iter+i]):
                breakCond = breakCond + 1
        if(breakCond == earlyBreakCount or iter == 10000):
            break
    
    print(W)
    final = []
    for i in range(0, 12):
        maxPos = 0
        for j in range(1, 100):
            if(np.abs(W[j]) > np.abs(W[maxPos])):
                maxPos = j
        final.append(maxPos)
        W[maxPos] = 0
    final.sort()
    print(final)
    return final, TEST(final)

def bunchaTests():
    maxVal = 0
    maxList = []
    for i in range(0, 30):
        currlist, currVal = main(10, 0.01, 0)
        if (currVal > maxVal):
            maxList = currlist
            maxVal = currVal
    print(maxVal)
    return maxList

def main2(earlyBreakCount, learningRate, lammy, thing):
    
    #Load Data
    file = open("mystery.dat", "r") 
    lines = file.readlines()
    
    data = []
    
    for i in range(0, len(lines)):
        data.append(lines[i].split(','))
        
    formatingData = np.asarray(data, dtype=float)
    formatingData = formatingData.T
    
    Y = []
    for i in range(0, 101):
        Y.append(formatingData[100][i])
    Y = np.asarray(Y)
    X = formatingData
    for i in range(0, 101):
        X[100][i] = 1
    X = X[[1, 2, 4, 6, 10, 12, 16, 18, 22, 28, 100], :]#[1, 2, 4, 6, 10, 12, 16, 18, 22, 28, 100]#[1, 2, 4, 7, 10, 14, 16, 18, 22, 28, 100]#[2, 4, 7, 10, 12, 14, 16, 18, 22, 28, 100]
    X = X.T
    
    print(X[0], Y[0])
    #W = np.zeros((101, 1), dtype=float)
    W = np.random.rand(11, 1)*.001

    
    validSamples = random.sample(list(range(0, 101)),  10)
    trainSamples = []
    
    for i in range (0, 101):
        if (i not in validSamples):
            trainSamples.append(i)
    validX = X[validSamples, :]
    validY = Y[validSamples]
    trainX = X[trainSamples, :]
    trainY = Y[trainSamples]
    
    validY = np.reshape(validY, (len(validY), 1))
    trainY = np.reshape(trainY, (len(trainY), 1))
    
    #TestLoss
    lastTrainLoss = LossA(W, trainX, trainY, lammy)
    lastValidLoss = LossA(W, validX, validY, lammy)
    #print(lastTrainLoss)
    #print(lastValidLoss)
    
    validLosses = [lastValidLoss]
    for i in range (0, earlyBreakCount):
        validLosses.append(lastValidLoss)
    iter = 0
    while (1 == 1):
        meanDecentGradient = decent(W, trainX, trainY, lammy)
        W = W + (learningRate * meanDecentGradient)
        #print(W.shape, meanDecentGradient)
        #input("hol up")
        
        currValidLoss = (LossA(W, validX, validY, lammy))
        validLosses.append(currValidLoss)
        iter = iter + 1
        print("Iter:",iter," Valid Loss:",currValidLoss)
        lastValidLoss = currValidLoss
        breakCond = 0
        for i in range (0, earlyBreakCount):
            if(validLosses[iter+1+i] > validLosses[iter+i]):
                breakCond = breakCond + 1
        if(breakCond == earlyBreakCount or iter == 150000):
            break
    return lastValidLoss
        
def asdf():
    lossfd = 0
    zxcvbcx = []
    zxcv = [1, 2, 4, 6, 7, 10, 12, 14, 16, 18, 22, 28, 100]
    for i in range(0, 11):
        for j in range((i+1), 12):
            temp = []
            for x in range(0, 12):
                if (x != j and x != i):
                    temp.append(zxcv[x])
            temp.append(100)
            xcvb = TEST(temp)
            if (xcvb > lossfd):
                lossfd = xcvb
                zxcvbcx = temp
        print(i)
    return zxcvbcx
            