import struct
import random
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neighbors import KDTree

def read_idx(filename):
    with open(filename, 'rb') as file:
        zero, data_type, dims = struct.unpack('>HBB', file.read(4))
        shape = tuple(struct.unpack('>I', file.read(4))[0] for d in range(dims))
        return np.fromstring(file.read(), dtype=np.uint8).reshape(shape)

def main(test_count, train_count, rand, prototypeK):
    train_data = read_idx("train-images.idx3-ubyte")
    train_labels = read_idx("train-labels.idx1-ubyte")
    test_data = read_idx("t10k-images.idx3-ubyte")
    test_labels = read_idx("t10k-labels.idx1-ubyte")
    
    #train
    
    train = []
    
    for i in range(0, 60000):
        train.append((train_data[i], train_labels[i]))
    
    #NN setup
    
    trainD = []
    trainL = []
    
    if (rand == 1):
        train = random.sample(train, train_count)
        
        for i in range(0, train_count):
            trainD.append(np.asarray(train[i][0]).reshape(-1))
            trainL.append(train[i][1])
    elif (rand == -1):
        for i in range(0, 60000):
            trainD.append(np.asarray(train[i][0]).reshape(-1))
            trainL.append(train[i][1])
    elif (rand == -2):
        random.shuffle(train)
        
        for i in range(0, train_count):
            trainD.append(np.asarray(train[i][0]).reshape(-1))
            trainL.append(train[i][1])
        for asdfabvadf in range(0, 10000):
            tree = KDTree(np.array(trainD))
            learningRate =((10000-asdfabvadf)/20000)
            print(asdfabvadf)
            for zxcv in range(0, 10):
                xamp = random.randint(0, 59999)
                dist, ind = tree.query([np.asarray(train[xamp][0]).reshape(-1)], k=1)
                if(train[xamp][1] == trainL[ind[0][0]]):
                    trainD[ind[0][0]] = trainD[ind[0][0]] + learningRate * (np.asarray(train[xamp][0]).reshape(-1) - trainD[ind[0][0]])
                else:
                    trainD[ind[0][0]] = trainD[ind[0][0]] - learningRate * (np.asarray(train[xamp][0]).reshape(-1) - trainD[ind[0][0]])
    else:
        tempTrainD = []
        tempTrainL = []
        for i in range(0, 60000):
            tempTrainD.append(np.asarray(train[i][0]).reshape(-1))
            tempTrainL.append(train[i][1])
        print("Generating Prototypes")

        prototypeFinder = [] # fill up this list with index + % closest

        for imgInt in range(0, 10):
            prototypeFinder.append([])

         #centroid region idea
        for index in range(0, 60000):
            prototypeFinder[tempTrainL[index]].append(index)
        avgImages = []
        for imgInt in range(0, 10):
            print(imgInt)
            avgImage = []
            for pixel in range(0, 784):
                avgPixVal = 0
                numIntImgs = len(prototypeFinder[imgInt])
                for imgIndex in range(0, numIntImgs):
                    avgPixVal = avgPixVal + tempTrainD[prototypeFinder[imgInt][imgIndex]][pixel]
                avgPixVal = avgPixVal / numIntImgs
                avgImage.append(avgPixVal)
            avgImages.append(avgImage)
            #print(avgImage)
        
        for imgInt in range(0, 10):
            prototypeSelector = []
            for imgIndex in range(0,  len(prototypeFinder[imgInt])):
                cent = -1
                centDist = 0
                for centroid in range (0, 10):
                    distToCent = np.linalg.norm(np.asarray(avgImages[centroid])-tempTrainD[prototypeFinder[imgInt][imgIndex]])# distance from this point to centroid
                    if (distToCent < centDist or cent == -1):
                        cent = centroid
                        centDist = distToCent
                if (cent != imgInt):
                    continue
                
                prototypeSelector.append((np.linalg.norm(np.asarray(avgImages[imgInt])-tempTrainD[prototypeFinder[imgInt][imgIndex]]), prototypeFinder[imgInt][imgIndex]))

            sorted(prototypeSelector)
            print(len(prototypeSelector))
            for selection in range((len(prototypeSelector)-1),(len(prototypeSelector) - int(train_count/10) - 1), -1):
                selectedIndex = prototypeSelector[selection][1]
                trainD.append(np.asarray(train[selectedIndex][0]).reshape(-1))
                trainL.append(train[selectedIndex][1])
            
    #test
    
    test = []
    
    for i in range(0, 10000):
        test.append((test_data[i], test_labels[i]))
    
    testD = []
    testL = []
    for i in range(0, test_count):
        testD.append(np.asarray(test[i][0]).reshape(-1))
        testL.append(test[i][1])
    
    neigh = KNeighborsClassifier(n_neighbors=1, weights='uniform', algorithm='auto')
    neigh.fit(trainD, trainL)
    
    print("Going around the neighborhood:")
    print(len(trainD))
    print(len(trainL))
    correct = neigh.score(testD, testL)           

    return (correct)
