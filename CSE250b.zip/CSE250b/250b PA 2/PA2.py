#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import random
import numpy as np
import matplotlib.pyplot as plt
from sklearn import linear_model, datasets
from sklearn.datasets import load_wine

def autoLogReg():
    #Load Data
    loadedData = load_wine()
    data = loadedData.data[:130]
    target = loadedData.target[:130]
    
    X = np.asarray(data)
    X = X.T
    for i in range(0, 13):
        minVal, maxVal = 0, 0
        for j in range(0, 130):
            if (X[i][j] > maxVal):
                maxVal = X[i][j]
            if (X[i][j] < minVal):
                minVal = X[i][j]
        X[i] = ((X[i]-minVal)/(maxVal-minVal))
    X = X.T
    Y = np.asarray(target)
    
    validSamplesA = random.sample(list(range(0, 59)),  6) 
    validSamplesB = random.sample(list(range(59, 130)),  7) 
    
    validSamples = validSamplesA + validSamplesB
    
    trainSamples = []
    
    for i in range (0, 130):
        if (i not in validSamples):
            trainSamples.append(i)
    validX = X[validSamples, :]
    validY = Y[validSamples]
    trainX = X[trainSamples, :]
    trainY = Y[trainSamples]
    
    logreg = linear_model.LogisticRegression(C=999999999999)
    #logreg.fit(trainX, trainY)
    logreg.fit(X, Y)
    #print(logreg.coef_)
    W = np.hstack((logreg.coef_, logreg.intercept_[:,None]))
    #print(W)
    
    #PART 2
    
    #Load Data
    loadedData = load_wine()
    data = loadedData.data[:130]
    target = loadedData.target[:130]

    #Convert 0s to -1s
    for i in range (0, 130):
        if (target[i] == 0):
            target[i] = -1
    
    #Normalize Data
    
    X = np.asarray(data)
    X = X.T
    for i in range(0, 13):
        minVal, maxVal = 0, 0
        for j in range(0, 130):
            if (X[i][j] > maxVal):
                maxVal = X[i][j]
            if (X[i][j] < minVal):
                minVal = X[i][j]
        X[i] = ((X[i]-minVal)/(maxVal-minVal))
    X = X.T
    X = np.insert(X, 13, 1, axis=1)
    
    Y = np.asarray(target)
    #print(X, np.reshape(Y,(130,1)).shape, W.T)
    
    FinLOSS = 0
    #print(Y)
    finalProbs = sigmoid(W.T, X, np.reshape(Y,(130,1)), 1)
    #print(finalProbs)
    for i in range (0, 130):
        if(finalProbs[i] != 1):
            FinLOSS = FinLOSS - np.log(finalProbs[i])
    print(FinLOSS)
    #return logreg.score(validX, validY)
    return FinLOSS

def randCoordinate():
    coord = random.randint(0, 13)
    return coord
    
def decent(W, X, Y):
    negY = -1 * Y
    probs = sigmoid(W, X, negY)
    Yprobs = (Y.flatten() * probs)
    decentVect = np.dot(X.T, Yprobs)
    meanDecentVect = (decentVect/(len(Y)))
    return meanDecentVect

def sigmoid(W, X, Y, printasdf=0):
    expVal = np.matmul(X, W)
    eVal = Y.flatten() * expVal.flatten()
    outProbs = 1/(1+np.exp(-eVal))
    return outProbs

def LossA(W, X, Y):
    expVal = np.dot(X, W)
    LossEQ = np.log((1+np.exp(-(expVal * Y))))
    return LossEQ.sum()

def main(earlyBreakCount, TPC, learningRate, selectChoice, momentum,banlist=[]):
    #random.seed(a=712624)
    #Load Data
    loadedData = load_wine()
    data = loadedData.data[:130]
    target = loadedData.target[:130]

    #Convert 0s to -1s
    for i in range (0, 130):
        if (target[i] == 0):
            target[i] = -1
    
    #Normalize Data
    
    X = np.asarray(data)
    X = X.T
    for i in range(0, 13):
        minVal, maxVal = 0, 0
        for j in range(0, 130):
            if (X[i][j] > maxVal):
                maxVal = X[i][j]
            if (X[i][j] < minVal):
                minVal = X[i][j]
        X[i] = ((X[i]-minVal)/(maxVal-minVal))
    X = X.T
    X = np.insert(X, 13, 1, axis=1)
    
    Y = np.asarray(target)
    
    #W = np.random.rand(14, 1)* 0.0001
    W = np.zeros((14, 1))
    moment = np.zeros((14,1))
    
    validSamplesA = random.sample(list(range(0, 59)),  6) 
    validSamplesB = random.sample(list(range(59, 130)),  7) 
    
    validSamples = validSamplesA + validSamplesB
    
    trainSamples = []
    
    for i in range (0, 130):
        if (i not in validSamples):
            trainSamples.append(i)
    validX = X[validSamples, :]
    validY = Y[validSamples]
    trainX = X[trainSamples, :]
    trainY = Y[trainSamples]
    
    validY = np.reshape(validY, (len(validY), 1))
    trainY = np.reshape(trainY, (len(trainY), 1))
    
    lowestValidLoss = 10000
    lowestValidWeights = 0
    valLosses = []
    trainLosses = []
    totalLosses = []
    #TestLoss
    lastTrainLoss = LossA(W, trainX, trainY)
    lastValidLoss = LossA(W, validX, validY)
    validLosses = [lastValidLoss]
    for i in range (0, earlyBreakCount):
        validLosses.append(lastValidLoss)
    iter = 0
    while (1 == 1):
        for trialsPerCheck in range(0,TPC):
            meanDecentGradient = decent(W, trainX, trainY)
            if(selectChoice == "Random"):
                decentCoord = randCoordinate()
            if(selectChoice == "Largest"):
                #Select Largest gradient
                decentCoord = 0
                for zxcv in range(0, 14):
                    if(zxcv in banlist):
                        continue
                    if(np.abs(meanDecentGradient[zxcv]) > np.abs(meanDecentGradient[decentCoord])):
                        decentCoord = zxcv
            W[decentCoord] = W[decentCoord] + (learningRate * meanDecentGradient[decentCoord]) + momentum * moment[decentCoord]
            moment[decentCoord] = moment[decentCoord] + (learningRate * meanDecentGradient[decentCoord])
        
        currValidLoss = (LossA(W, validX, validY))
        currTrainLoss = (LossA(W, trainX, trainY))
        LASDFSDF = (LossA(W, np.concatenate([trainX, validX]), np.concatenate([trainY, validY])))
        if (lowestValidLoss > currValidLoss): 
            lowestValidLoss = currValidLoss
            lowestValidWeights = W
        valLosses.append(currValidLoss)
        trainLosses.append(currTrainLoss)
        totalLosses.append(LASDFSDF)
        validLosses.append(currValidLoss)
        iter = iter + 1
        #print("Iter:",iter," Valid Loss:",currValidLoss,"Train Loss:", currTrainLoss)
        breakCond = 0
        for i in range (0, earlyBreakCount):
            if(validLosses[iter+1+i] >= validLosses[iter+i]):
                breakCond = breakCond + 1
        if(breakCond == earlyBreakCount or lowestValidLoss * 10 < currValidLoss):
            break
        
    correct = 0
    finalProbs = sigmoid(W, X, np.reshape(Y,(130,1)), 1)
    for i in range (0, 130):
        if(finalProbs[i] > 0.5):
            correct = correct + 1
    """
    plt.plot(valLosses, label='Validation Set')
    plt.plot(trainLosses, label='Training Set')
    plt.plot(totalLosses, label='Total Set')
    plt.xlabel('Validation Check (5 updates per check)')
    plt.ylabel('Loss')
    plt.title("Loss")
    plt.legend()
    plt.savefig('Loss', bbox_inches='tight')
    plt.show()
    plt.close
    """
    #LOSS
    #Load Data
    loadedData = load_wine()
    data = loadedData.data[:130]
    target = loadedData.target[:130]

    #Convert 0s to -1s
    for i in range (0, 130):
        if (target[i] == 0):
            target[i] = -1
    
    #Normalize Data
    
    X = np.asarray(data)
    X = X.T
    for i in range(0, 13):
        minVal, maxVal = 0, 0
        for j in range(0, 130):
            if (X[i][j] > maxVal):
                maxVal = X[i][j]
            if (X[i][j] < minVal):
                minVal = X[i][j]
        X[i] = ((X[i]-minVal)/(maxVal-minVal))
    X = X.T
    X = np.insert(X, 13, 1, axis=1)
    
    Y = np.asarray(target)
    #print(LossA(lowestValidWeights, X, np.reshape(Y,(130,1))))
    #print((correct/130))
    #return W
    #return LossA(lowestValidWeights, X, np.reshape(Y,(130,1)))
    return lowestValidWeights, lowestValidLoss

def kSparse(a,b,c,d,e,k):
    banlist = []
    Wcurr = 0
    loss = 0
    while(1 == 1):
        if(k > 13):
            break
        Wcurr, loss = main(a, b, c, d, e, banlist)
        zeroCount = 0
        for i in range(13):
            if(Wcurr[i] == 0):
                zeroCount = zeroCount + 1
        if(zeroCount >= (13 - k)):
            break
        lowest = 10000000
        lowestFeat = -1
        for i in range(13):
            if (np.abs(Wcurr[i]) < lowest and not(i in banlist)):
                lowest = np.abs(Wcurr[i])
                lowestFeat = i
        banlist.append(lowestFeat)
    print(Wcurr)
    return loss